import React,{ useEffect, useState,useContext,useReducer } from 'react';
import { useDataSource } from '../hooks/useDataSource';
function reducer(state, action) {
  switch (action.type) {
    case"delete":{
      return state.filter((stateEl) => stateEl.id !== action.id)
    }
    case "add":{
      return [...state,action.newEl];
    }
    case "update":{

    }
    case "initData":{
        return action.tasksCollection;
    }   
  }
}
const TaskModel = ()=>{
    const {data,loading} = useDataSource();
    const [tasks,dispatch] = useReducer(reducer,[]);
    useEffect(()=>{
        if(!loading)
        dispatch("init",{tasksCollection:data});
    },[loading]);

}