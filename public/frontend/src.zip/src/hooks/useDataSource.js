import React,{ useEffect, useState,useContext,useReducer } from 'react';
import axios from '../api/axios';
/*function reducer(state, action) {
  switch (action.type) {
    case"delete":{
      return state.filter((stateEl) => stateEl.id !== action.id)
    }
    case "add":{
      return [...state,action.newEl];
    }
    case "update":{

    }
  }
}*/
export const useDataSource =(entity,fetch=true)=> {
  const path = 'api/'.concat(entity);

  const [data, setData] = useState({});
  
  
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data: response } = await axios.get(path);
        setData(response.data);
      } catch (error) {
        setData({error:true,message:error.response.data.message});
      }
      setLoading(false);
    };
    if( loading && fetch){
      fetchData();
    }
    

  },[loading]);
  const create = async(entityObj) => {
    const { data: response } = await axios.post(path,entityObj);
    return response.data;
  }
  const update = async(resorce_id,data)=>{
     const { data: response } = await axios.put(path.concat('/'+resorce_id),data);
     return response.data;
  }
  const updateOne = async(data)=>{
    const { data: response } = await axios.put(path,data);
    return response.data;
 }
  const destroy = async(resorce_id)=>{
    await axios.delete(path.concat('/'+resorce_id));
  }

  return {data,loading,updateOne,setLoading,create,setData,update,destroy};
};




